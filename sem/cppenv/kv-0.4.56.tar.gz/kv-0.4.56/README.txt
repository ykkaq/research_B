kv - a C++ Library for Verified Numerical Computation
version 0.4.56

http://verifiedby.me/kv/

Masahide Kashiwagi  kashi@waseda.jp

This software is released under the MIT License, see LICENSE.txt.
